import React from "react";
import Scene from "./components/Canvas/Scene";
import LeftSidebar from "./components/Sidebar/LeftSidebar";
import RightSidebar from "./components/Sidebar/RightSidebar";

export default function App() {
  return (
    <div style={{
      display: "flex",
      width: "100vw",
      height: "100vh",
      backgroundColor: "#0d1117",
      color: "#ffffff"
    }}>
      <LeftSidebar />
      <div style={{ flex: 1, position: "relative" }}>
        <Scene />
        <div style={{
          position: "absolute",
          top: "16px",
          left: "50%",
          transform: "translateX(-50%)",
          backgroundColor: "rgba(0,0,0,0.6)",
          padding: "6px 16px",
          borderRadius: "9999px",
          fontSize: "12px",
          color: "#d1d5db",
          backdropFilter: "blur(4px)"
        }}>
          🖱 Drag to rotate · Scroll to zoom
        </div>
      </div>
      <RightSidebar />
    </div>
  );
}