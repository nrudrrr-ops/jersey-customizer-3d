import { create } from "zustand";
import { persist } from "zustand/middleware";

export const useStore = create(
  persist(
    (set) => ({
      primaryColor: "#e11d48",
      secondaryColor: "#ffffff",
      sponsorColor: "#000000",
      trimColor: "#facc15",
      numberColor: "#ffffff",
      style: "solid",
      activePart: "shirt",
      teamName: "JERSEYKART",
      playerName: "PLAYER",
      playerNumber: "10",
      logo: null,

      setColor: (key, value) => set({ [key]: value }),
      setStyle: (style) => set({ style }),
      setActivePart: (part) => set({ activePart: part }),
      setText: (key, val) => set({ [key]: val }),
      setLogo: (logo) => set({ logo }),

      reset: () =>
        set({
          primaryColor: "#e11d48",
          secondaryColor: "#ffffff",
          sponsorColor: "#000000",
          trimColor: "#facc15",
          numberColor: "#ffffff",
          style: "solid",
          teamName: "JERSEYKART",
          playerName: "PLAYER",
          playerNumber: "10",
          logo: null,
        }),
    }),
    { name: "jersey-config" }
  )
);