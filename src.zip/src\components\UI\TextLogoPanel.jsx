import React from "react";
import { useStore } from "../../store/useStore";

export default function TextLogoPanel() {
  const { teamName, playerName, playerNumber, setText, setLogo } = useStore();

  const handleLogo = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setLogo(reader.result);
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-3">
      <h3 className="font-bold text-sm uppercase tracking-wider text-accent">Text & Logo</h3>
      <Field label="Team Name" value={teamName} onChange={(v) => setText("teamName", v)} />
      <Field label="Player Name" value={playerName} onChange={(v) => setText("playerName", v)} />
      <Field label="Number" value={playerNumber} onChange={(v) => setText("playerNumber", v)} />
      <div>
        <label className="text-xs text-gray-400">Upload Logo (PNG)</label>
        <input
          type="file"
          accept="image/png"
          onChange={handleLogo}
          className="block w-full text-xs mt-1 file:mr-2 file:py-1 file:px-2 file:bg-accent file:text-black file:rounded file:border-0"
        />
      </div>
    </div>
  );
}

function Field({ label, value, onChange }) {
  return (
    <div>
      <label className="text-xs text-gray-400">{label}</label>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full bg-black/40 border border-white/10 rounded-md px-2 py-1.5 text-sm mt-1"
      />
    </div>
  );
}