import React, { useEffect, useMemo, useRef } from "react";
import { useTexture } from "@react-three/drei";
import * as THREE from "three";
import { useStore } from "../../store/useStore";

function buildShirtTexture(primary, secondary, trim, style) {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext("2d");

  if (style === "solid") {
    ctx.fillStyle = primary;
    ctx.fillRect(0, 0, 512, 512);
  } else if (style === "halves") {
    ctx.fillStyle = primary;
    ctx.fillRect(0, 0, 256, 512);
    ctx.fillStyle = secondary;
    ctx.fillRect(256, 0, 256, 512);
  } else if (style === "stripes") {
    const w = 64;
    for (let x = 0; x < 512; x += w) {
      ctx.fillStyle = Math.floor(x / w) % 2 === 0 ? primary : secondary;
      ctx.fillRect(x, 0, w, 512);
    }
  } else if (style === "gradient") {
    const grad = ctx.createLinearGradient(0, 0, 0, 512);
    grad.addColorStop(0, primary);
    grad.addColorStop(1, secondary);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, 512);
  } else {
    ctx.fillStyle = primary;
    ctx.fillRect(0, 0, 512, 512);
  }

  ctx.fillStyle = trim;
  ctx.fillRect(0, 0, 512, 18);

  const tex = new THREE.CanvasTexture(canvas);
  tex.needsUpdate = true;
  return tex;
}

export default function Jersey({ nodes, materials }) {

  const primaryColor   = useStore((s) => s.primaryColor);
  const secondaryColor = useStore((s) => s.secondaryColor);
  const trimColor      = useStore((s) => s.trimColor);
  const style          = useStore((s) => s.style);

  const fabricNormal = useTexture("/fabric.jpg");

  useEffect(() => {
    if (!fabricNormal) return;
    fabricNormal.wrapS       = THREE.RepeatWrapping;
    fabricNormal.wrapT       = THREE.RepeatWrapping;
    fabricNormal.repeat.set(10, 10);
    fabricNormal.needsUpdate = true;
  }, [fabricNormal]);

  const shirtTexture = useMemo(
    () => buildShirtTexture(primaryColor, secondaryColor, trimColor, style),
    [primaryColor, secondaryColor, trimColor, style]
  );

  const matRef = useRef();
  useEffect(() => {
    if (!matRef.current) return;
    matRef.current.map         = shirtTexture;
    matRef.current.normalMap   = fabricNormal;
    matRef.current.needsUpdate = true;
  }, [shirtTexture, fabricNormal]);

  return (
    <group rotation={[-Math.PI / 2, 0, 0]}>
      <primitive object={nodes._rootJoint} />

      {/* texture_2 = JERSEY — Object_9 */}
      <skinnedMesh
        geometry={nodes.Object_9.geometry}
        skeleton={nodes.Object_9.skeleton}
        castShadow
      >
        <meshStandardMaterial
          ref={matRef}
          map={shirtTexture}
          normalMap={fabricNormal}
          normalScale={new THREE.Vector2(5, 5)}
          roughness={0.75}
          metalness={0.0}
          envMapIntensity={0.4}
        />
      </skinnedMesh>

      {/* texture_8 = Object_10 — shorts ya kuch aur */}
      <skinnedMesh geometry={nodes.Object_10.geometry} material={materials.texture_8} skeleton={nodes.Object_10.skeleton} />
      <skinnedMesh geometry={nodes.Object_11.geometry} material={materials.texture_5} skeleton={nodes.Object_11.skeleton} />
      <skinnedMesh geometry={nodes.Object_12.geometry} material={materials.texture_3} skeleton={nodes.Object_12.skeleton} />
      <skinnedMesh geometry={nodes.Object_13.geometry} material={materials.texture_4} skeleton={nodes.Object_13.skeleton} />
      <skinnedMesh geometry={nodes.Object_14.geometry} material={materials.texture_6} skeleton={nodes.Object_14.skeleton} />
      <skinnedMesh geometry={nodes.Object_15.geometry} material={materials.texture_1} skeleton={nodes.Object_15.skeleton} />
      <skinnedMesh geometry={nodes.Object_16.geometry} material={materials.texture_7} skeleton={nodes.Object_16.skeleton} />
      <skinnedMesh geometry={nodes.Object_17.geometry} material={materials.texture_9} skeleton={nodes.Object_17.skeleton} />
    </group>
  );
}