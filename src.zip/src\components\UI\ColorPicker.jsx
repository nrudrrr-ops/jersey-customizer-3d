import React from "react";
import { HexColorPicker } from "react-colorful";
import { useStore } from "../../store/useStore";

const FIELDS = [
  { key: "primaryColor",   label: "Primary"   },
  { key: "secondaryColor", label: "Secondary" },
  { key: "sponsorColor",   label: "Sponsor"   },
  { key: "trimColor",      label: "Trim"      },
  { key: "numberColor",    label: "Number"    },
];

export default function ColorPicker() {
  const store = useStore();
  const [active, setActive] = React.useState("primaryColor");

  return (
    <div className="space-y-3">
      <h3 className="font-bold text-sm uppercase tracking-wider text-accent">Colors</h3>
      <div className="grid grid-cols-5 gap-2">
        {FIELDS.map((f) => (
          <button
            key={f.key}
            onClick={() => setActive(f.key)}
            className={`h-10 rounded-lg border-2 transition ${
              active === f.key ? "border-accent scale-110" : "border-transparent"
            }`}
            style={{ background: store[f.key] }}
            title={f.label}
          />
        ))}
      </div>
      <p className="text-xs text-gray-400">{FIELDS.find(f => f.key === active).label}</p>
      <HexColorPicker
        color={store[active]}
        onChange={(c) => store.setColor(active, c)}
        style={{ width: "100%" }}
      />
      <input
        type="text"
        value={store[active]}
        onChange={(e) => store.setColor(active, e.target.value)}
        className="w-full bg-black/40 border border-white/10 rounded-md px-2 py-1 text-sm"
      />
    </div>
  );
}