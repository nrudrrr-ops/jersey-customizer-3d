import React from "react";
import * as THREE from "three";
import { useStore } from "../../store/useStore";

export default function Jersey({ nodes, materials }) {
  const primaryColor = useStore((s) => s.primaryColor);

  return (
    <group rotation={[-Math.PI / 2, 0, 0]}>
      <primitive object={nodes._rootJoint} />

      <skinnedMesh
        geometry={nodes.Object_9.geometry}
        skeleton={nodes.Object_9.skeleton}
        castShadow
      >
        <meshStandardMaterial color="red" />
      </skinnedMesh>

      <skinnedMesh geometry={nodes.Object_10.geometry} material={materials.texture_8} skeleton={nodes.Object_10.skeleton} />
      <skinnedMesh geometry={nodes.Object_11.geometry} material={materials.texture_5} skeleton={nodes.Object_11.skeleton} />
      <skinnedMesh geometry={nodes.Object_12.geometry} material={materials.texture_3} skeleton={nodes.Object_12.skeleton} />
      <skinnedMesh geometry={nodes.Object_13.geometry} material={materials.texture_4} skeleton={nodes.Object_13.skeleton} />
      <skinnedMesh geometry={nodes.Object_14.geometry} material={materials.texture_6} skeleton={nodes.Object_14.skeleton} />
      <skinnedMesh geometry={nodes.Object_15.geometry} material={materials.texture_1} skeleton={nodes.Object_15.skeleton} />
      <skinnedMesh geometry={nodes.Object_16.geometry} material={materials.texture_7} skeleton={nodes.Object_16.skeleton} />
      <skinnedMesh geometry={nodes.Object_17.geometry} material={materials.texture_9} skeleton={nodes.Object_17.skeleton} />
    </group>
  );
}